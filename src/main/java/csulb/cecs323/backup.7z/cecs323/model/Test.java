package csulb.cecs323.model;

import java.util.GregorianCalendar;

public class Test {

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		
		GregorianCalendar yay = new GregorianCalendar(1958, 8, 29);
		
		
		System.out.println(yay.get(yay.YEAR) + " " + yay.get(yay.MONTH) + " " + yay.get(yay.DAY_OF_MONTH));

	}

}
