
package csulb.cecs323.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;

/**
 * OfficialVideo class to model official music video of a song. 
 * It has some basic information such as title, length, date release, and view count.
 */
@Entity
@IdClass(OfficialVideoKey.class)
public class OfficialVideo {
	
	@Id
   	private String title;
	
	@Id
	private int yearReleased;
	
   	private int length; 				
   	private int viewCount;
   	

   	@OneToOne
    @JoinColumns ({
    	@JoinColumn(name = "title", nullable = false),
    	@JoinColumn(name = "yearReleased", nullable = false)
    })
    private Song song;
   	
   	/**
   	 * Empty constructor
   	 */
   	public OfficialVideo() {}
   	
   	public OfficialVideo(String title, int yearReleased, int length, int viewCount) {
   		this.title = title;
   		this.yearReleased = yearReleased;
   		this.length = length;
   		this.viewCount = viewCount;
   	}
   	
   	

   	public String getTitle() {
   		return title;
   	}

   	public void setTitle(String title) {
   		this.title = title;
   	}

   	public int getReleaseYear() {
   		return yearReleased;
   	}
   	
   	public void setReleaseYear(int yearReleased) {
   		this.yearReleased = yearReleased;
   	}
   	
   	public int getLength() {
   		return length;
   	}
   	
   	public void setLength(int length){
   		this.length = length;
   	}
   	
   	public int getPlayCount() {
   		return viewCount;
   	}
   	
   	public void setPlayCount(int playCount) {
   		this.viewCount = playCount;
   	}
   	
   	
   	
   	
}
