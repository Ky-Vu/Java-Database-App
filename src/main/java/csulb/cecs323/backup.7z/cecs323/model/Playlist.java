package csulb.cecs323.model;

import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.TemporalType;
import javax.persistence.Temporal;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.ManyToMany;

/**
 * Playlist class to model the playlist a music streaming service subscriber has.
 * It contain some basic information such as name of the playlist, number of songs, 
 * total duration of songs in playlist.
 */
@Entity
@Table(name = "Playlist")
public class Playlist {
   @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;

   private String name;
   private int numOfSongs;
   
   private int totalDuration; //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> What type?
   
   @Temporal(TemporalType.DATE)
   private GregorianCalendar dateCreated;

   @ManyToOne
   private User owner;
   
   @ManyToMany
   @JoinTable(name = "SongInPlaylist")
   private List<Song> songs;
   
   
   public Playlist() {
	   
   }
   
   public Playlist(String name, GregorianCalendar dateCreated, int numOfSongs, int totalDuration) {
	   this.name = name;
	   this.dateCreated = dateCreated;
	   this.numOfSongs = numOfSongs;
	   this.totalDuration = totalDuration;
   }
   
   
   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public GregorianCalendar getDateCreated() {
      return dateCreated;
   }
   
   public void setDateCreated(GregorianCalendar dateCreated) {
	   this.dateCreated = dateCreated;
   }
   
   public int getNumOfSongs() {
	   return numOfSongs;
   }
   
   public void setNumOfSongs(int numOfSongs) {
	   this.numOfSongs = numOfSongs;
   }
   
   public int getTotalDuration() {
	   return totalDuration;
   }
   
   public void setTotalDuration(int totalDuration) {
	   this.totalDuration = totalDuration;
   }
   
   public User getOwner() {
	   return owner;
   }
   
   public void setOwner(User owner) {
	   this.owner = owner;
   }
  
   public List<Song> getSongs(){
	   return songs;
   }
   
   public void setSongs(List<Song> songs) {
	   this.songs = songs;
   }
   
   public void addSong(Song song) {
	   if (!song.getPlaylist().contains(this)) {
		   this.songs.add(song);
	   }
	   
	   if (song.getPlaylist().contains(this)) {
		   if (!this.songs.contains(song)) {
			   this.songs.add(song);
		   }
	   }
   }
   
   
}