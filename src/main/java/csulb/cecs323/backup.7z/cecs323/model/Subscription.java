package csulb.cecs323.model;

public enum Subscription {
	
	BASIC, PREMIUM 
	
	
}
