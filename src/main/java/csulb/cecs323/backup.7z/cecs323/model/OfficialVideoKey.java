package csulb.cecs323.model;
import java.io.Serializable;
import java.util.GregorianCalendar;


public class OfficialVideoKey implements Serializable{
	private String title;
	private GregorianCalendar dateReleased;
}