package csulb.cecs323.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 * Genre class is to model the popular Genre of song. It has just the genre name. 
 */
@Entity
@Table(name = "Genres")
public class Genre {
   
   @Id
   private String title;
   
   @ManyToMany(mappedBy = "genres", cascade = CascadeType.PERSIST)
   private List<Song> songs;
   
   @ManyToMany(mappedBy = "genres", cascade = CascadeType.PERSIST)
   private List<User> users;
   
   /**
    * Empty constructor
    */
   public Genre() {}
   
   public Genre(String title) {
	   this.title = title;
   }
   
   public String getTitle() {
	   return title;
   }
   
   public void setTitle(String title){
	   this.title = title;
   }
   
   public List<User> getPrefers(){
	   return this.users;
   }
   
   public void setPrefers(List<User> users) {
	   this.users = users;
   }
   
   public void addPrefers(User user) {
	   if (!user.getGenres().contains(this)) {
		   this.users.add(user);
	   }
	   
	   if (user.getGenres().contains(this)) {
		   if (!this.users.contains(user)) {
			   this.users.add(user);
		   }
	   }
   }
   
   public List<Song> getSongs(){
	   return this.songs;
   }
   
   public void setSongs(List<Song> songs) {
	   this.songs = songs;
   }
   
   public void addSong(Song song) {
	   if (!song.getGenres().contains(this)) {
		   this.songs.add(song);
	   }
	   
	   if (song.getGenres().contains(this)) {
		   if (!this.songs.contains(song)) {
			   this.songs.add(song);
		   }
	   }
   }
   
   
}