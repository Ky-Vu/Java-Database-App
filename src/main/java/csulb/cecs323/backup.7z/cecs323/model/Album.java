package csulb.cecs323.model;

import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.ManyToOne;
import javax.persistence.ManyToMany;
import javax.persistence.JoinTable;

@Entity
@Table(name = "Album")
public class Album {
	
	/** Name of JPQL query to find all Album entities */
	public static final String FIND_ALL = "Album.findAll";

	/** Name of JPQL query to find Album entities by first and last name */
	public static final String FIND_BY_NAME = "Album.findByName";
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String title;
	@Temporal(TemporalType.DATE)
	private GregorianCalendar dateReleased;
	private double revenue;
	private int numSongs;
	
	@ManyToOne
	private Artist artist;
	
	@ManyToMany
	@JoinTable(name = "SongInAlbum")
	private List<Song> songs;
	
	/*
	 * Empty constructor
	 */
	public Album() {}
	
	public Album(String title, GregorianCalendar dateReleased) {
		this.title = title;
		this.dateReleased = dateReleased;
	}
	
	public Album(String title, GregorianCalendar dateReleased, double revenue, int numSongs) {
		this.title = title;
		this.dateReleased = dateReleased;
		this.revenue = revenue;
		this.numSongs = numSongs;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public GregorianCalendar getDateReleased() {
		return this.dateReleased;
	}
	
	public void setDateReleased(GregorianCalendar dateReleased) {
		this.dateReleased = dateReleased;
	}
	
	public double getRevenue() {
		return this.revenue;
	}
	
	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}
	
	public int getNumSongs() {
		return this.numSongs;
	}
	
	public void setNumSongs(int numSongs) {
		this.numSongs = numSongs;
	}
	
	public Artist getArtist() {
		return this.artist;
	}
	
	public void setArtist(Artist artist) {
		this.artist = artist;
	}
	
	public List<Song> getSongs() {
		return this.songs;
	}
	
	public void setSongs(List<Song> songs) {
		this.songs = songs;
	}
	
	public void addSong(Song song) {
		if (!song.getAlbums().contains(this)) {
			   this.songs.add(song);
		}
		   
		if (song.getAlbums().contains(this)) {
			if (!this.songs.contains(song)) {
				this.songs.add(song);
			}
		}
	}
	
	public String toString() {
		String album = String.format("Title: %s%nReleased: %tD", this.getTitle(), this.getDateReleased());
		return album;
	}
	

}
