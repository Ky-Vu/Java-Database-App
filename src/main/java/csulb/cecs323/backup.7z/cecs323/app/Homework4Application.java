/*
 * Licensed under the Academic Free License (AFL 3.0).
 *     http://opensource.org/licenses/AFL-3.0
 *
 *  This code is distributed to CSULB students in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, other than educational.
 *
 *  2018 Alvaro Monge <alvaro.monge@csulb.edu>
 *
 */

package csulb.cecs323.app;

import csulb.cecs323.model.Album;
import csulb.cecs323.model.Artist;
import csulb.cecs323.model.Song;

import java.util.GregorianCalendar;
import java.util.logging.Logger;
import java.util.stream.IntStream;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 * A simple application to demonstrate how to persist an object in JPA.
 *
 * This is for demonstration and educational purposes only.
 */
public class Homework4Application {
   private EntityManager entityManager;

   private static final Logger LOGGER = Logger.getLogger(Homework4Application.class.getName());

   public Homework4Application(EntityManager manager) {
      this.entityManager = manager;
   }

   public static void main(String[] args) {
      LOGGER.fine("Creating EntityManagerFactory and EntityManager");
      EntityManagerFactory factory = Persistence.createEntityManagerFactory("homework4_PU");
      EntityManager manager = factory.createEntityManager();
      Homework4Application hw4application = new Homework4Application(manager);


      // Any changes to the database need to be done within a transaction.
      // See: https://en.wikibooks.org/wiki/Java_Persistence/Transactions

      LOGGER.fine("Begin of Transaction");
      EntityTransaction tx = manager.getTransaction();

      tx.begin();
      try {
    	  hw4application.loadInitialData();
      } catch (Exception e) {
    	  e.printStackTrace();
      }

      tx.commit();
      LOGGER.fine("End of Transaction");
      System.out.println("/nDone!");

   }

	   
	   private void loadInitialData(){
		   // Create a TypedQuery<> object to executed a named JPQL query
		   TypedQuery<Artist> checkArtist = entityManager.createNamedQuery(Artist.FIND_BY_NAME, Artist.class);
		   		   
		   Query q1 = entityManager.createQuery(
				  "SELECT a.fName AS �Firstname�, a.lName AS �Lastname�, al.title As �Album Title�,"
				+ "s.title AS �Songs in Album�" 
		   		+ " FROM Artist a" 
		   		+ "INNER JOIN Album al ON a.id = al.id" 
		   		+ "  INNER JOIN SongInAlbum sial ON al.title = sial.albumTitle AND  al.albumReleaseDate = sial.albumReleaseDate" 
		   		+ "	 INNER JOIN Song s ON sial.songTitle = s.title AND sial.songReleaseYear = s.yearReleased " 
		   		+ "  WHERE NOT EXISTS (SELECT *" 
		   		+ "				FROM Artist recArtist INNER JOIN Album al2 ON recArtist.id = al2.id" 
		   		+ "				WHERE a.id = recArtist.id AND al.dateReleased < al2.dateReleased)" 
		   		+ " GROUP BY al.title, a.fName, a.lName, s.title"
				);
		   
		   Query q2 = entityManager.createQuery(
				  "SELECT g.title, COUNT(sg.songTitle) AS �total songs�, AVG(s.length) / 60 AS �Average Song Length in minutes�" 
		   		+ "FROM genre g LEFT OUTER JOIN SongGenre sg ON g.title = sg.genre INNER JOIN Song s ON sg.songTitle = s.title AND sg.songReleaseYear = s.yearReleasd" 
		   		+ "GROUP BY sg.genre");
		   
		   Query q3 = entityManager.createQuery(
				  "SELECT a.fName AS �Firstname�, a.lName AS �Lastname�, g.title AS �Genre�  FROM Artist a" 
		   		+ "INNER JOIN SongRecord sr ON a.id = sr.artistID"
		   		+ "INNER JOIN Song s ON sr.songTitle = s.title AND sr.songReleaseYear = s.yearReleased" 
		   		+ "INNER JOIN Song_Genre sg ON s.yearReleased = sg.songReleaseYear"
		   		+ "INNER JOIN Genre g ON sg.genre = g.title"
		   		+ "GROUP BY a.id, a.fName, a.lName, g.title" 
		   		+ "HAVING COUNT(DISTINCT g.title) = 1");
		   
		   Query q4 = entityManager.createQuery(
				  "SELECT a1.fName AS �Firstname�, a1.lName AS �Lastname�, s1.title AS �Song Title�"
		   		+ "FROM Artist a1 INNER JOIN SongRecord sr1 ON a1.id = sr1.artistID INNER JOIN Song s1 ON sr1.songTitle = s1.title AND sr1.songReleaseYear = s1.yearReleased" 
		   		+ "WHERE NOT EXIST (SELECT * FROM Artist a2 INNER JOIN SongRecord sr2 ON a2.id = sr2.artistID WHERE a1.id <> a2.id AND sr1.songTitle = sr2.songTitle AND sr1.songReleaseYear = sr2.songReleaseYear)" 
		   		+ "GROUP BY sr1.artistID, a1.fName, a1.lName, s1.title" 
		   		+ "HAVING COUNT(sr1.songTitle) >= 2" 
		   		);
		   
		   Query q5 = entityManager.createQuery(
				  "SELECT s1.title AS �Song Title�, s1.yearReleased AS �Song Release Year�, s1.playCount AS �Play Count�, v.title AS �Official Video Title�,"
				+ "v.yearReleased AS �Video Release Year�, v.viewCount AS �View Count�" 
		   		+ "FROM Song s1 LEFT OUTER JOIN OfficialVideo v ON s1.title = v.songTitle AND s.yearReleased = v.songReleaseYear"
		   		+ "WHERE s1.yearReleased BETWEEN 2010 and 2018 AND EXISTS (SELECT * FROM Song s2 INNERJOIN SongGenre sg ON s.title = sg.songTitle AND s.yearReleased = sg.songReleaseYear INNERJOIN Genre g ON sg.genre = g.title WHERE s2.title = s1.title AND s2.yearReleased = s1.yearReleased AND g.title = �Hip Hop�)" 
		   		);
		   
		   Query q6 = entityManager.createQuery(
				  "SELECT u1.fName AS �First Name�, u1.lName AS �Last Name�, u1.subscriptionType AS �Subscription Type�, g1.title AS �Genre�"
		   		+ "FROM User u1 INNER JOIN UserGenre ug1 ON u1.id = ug1.userID INNER JOIN Genre g1 ON ug1.genre = g1.title"
		   		+ "WHERE NOT EXIST (SELECT * FROM User u2 INNER JOIN UserGenre ug2 ON u2.id = ug2.userID WHERE u1.id = u2.id AND ug1.genre <> ug2.genre)");
		   
		   IntStream.range(0, INITIAL_ALBUMS.length).forEach(i -> {
			   Album album = INITIAL_ALBUMS[i];
	           album.setArtist(INITIAL_ARTISTS[ALBUM_OWNERS[i]]);

	           // ownership is a bi-directional relationship, so we must establish the relationship on both sides
	           INITIAL_ARTISTS[ALBUM_OWNERS[i]].addAlbum(album);
		   });
		   
		   
		   for (Artist artist : INITIAL_ARTISTS){
			   entityManager.persist(artist);
		   }
		   
		   for (Album album : INITIAL_ALBUMS){
			   entityManager.persist(album);
		   }
		   
		   for(Song song : INITIAL_SONG){
			   entityManager.persist(song);
		   }
	   }
	   
	   private static final Artist[] INITIAL_ARTISTS = new Artist[]{
		         new Artist("Michael", "Jackson", new GregorianCalendar(1958, 8, 29), Artist.Sex.Male, 175192),
		         new Artist("Kwon", "Bo-ah", new GregorianCalendar(1986, 11, 5), Artist.Sex.Female, 13248),
		         new Artist("Adrian", "von Ziegler", new GregorianCalendar(1990, 3, 9), Artist.Sex.Male, 10536750),
		         new Artist("Keenon Daequan", "Jackson", new GregorianCalendar(1958, 8, 29), Artist.Sex.Male, 175192),
		         new Artist("Robyn Rihanna", "Fenty", new GregorianCalendar(1988, 2, 20), Artist.Sex.Female, 29789418),
		         new Artist("Juan Carlos", "Rosado", new GregorianCalendar(1992, 3, 13), Artist.Sex.Male, 39604646),
		         new Artist("Kimberlee Dawn", "Walker", new GregorianCalendar(1981, 12, 19), Artist.Sex.Female, 456242),
		         new Artist("Deborah", "Wesoff-Kowalski", new GregorianCalendar(1966, 3, 10), Artist.Sex.Female, 76175),
		         new Artist("Khalid", "Robinson", new GregorianCalendar(1998, 2, 11), Artist.Sex.Male, 41437993),
		         new Artist("Adrian", "von Ziegler", new GregorianCalendar(1989, 12, 25), Artist.Sex.Male, 58456),
		         new Artist("Michael", "Jackson", new GregorianCalendar(1958, 8, 29), Artist.Sex.Male, 175192),
		   };
	   
	   
	   public static final Album[] INITIAL_ALBUMS = new Album[] {
		       new Album("My Krazy Life", new GregorianCalendar(2014, 1, 1), 421500, 14),
		       new Album("Stay Dangerous", new GregorianCalendar(2018, 8, 3), 5000000, 15),
		       new Album("Red Friday", new GregorianCalendar(2016, 11, 25), 679800, 8),
		       new Album("Anti", new GregorianCalendar(2016, 1, 27), 3000000, 13),
		       new Album("Loud", new GregorianCalendar(2010, 11, 12), 1800000, 11),
		       new Album("Talk That Talk", new GregorianCalendar(2011, 11, 18), 1500000, 11),
		       new Album("Aura", new GregorianCalendar(2018, 8, 24), 1238940, 20),
		       new Album("Odisea", new GregorianCalendar(2017, 8, 25), 1083401, 16),
		       new Album("Here Is My Song", new GregorianCalendar(2008, 1, 1), 189024, 10),
		       new Album("On My Side", new GregorianCalendar(2017, 5, 21), 1284840, 12),
		       new Album("When Christmas Comes", new GregorianCalendar(2014, 11, 4), 3210598, 17),
		       new Album("Lookout Weekend", new GregorianCalendar(2013, 7, 10), 1308, 8),
		       new Album("She's Back", new GregorianCalendar(1995, 11, 21), 89304, 12),
		       new Album("American Teen", new GregorianCalendar(2017, 3, 3), 520389, 15),
		       new Album("Requiem", new GregorianCalendar(2010, 6, 1), 128952, 17),
		       new Album("The Celtic Collection", new GregorianCalendar(2012, 12, 12), 589340, 23),
		       new Album("Moonsong", new GregorianCalendar(2016, 12, 12), 352834, 20),
		       new Album("His Hand In Mine", new GregorianCalendar(1960, 11, 10), 3489201, 8),
		       new Album("That's the Way It Is", new GregorianCalendar(1970, 11, 11), 9840321, 6),
		       new Album("Today", new GregorianCalendar(1975, 5, 7), 9273410, 5),
		       new Album("Listen to my Heart", new GregorianCalendar(2002, 3, 13), 320025, 14),
		       new Album("Outgrow", new GregorianCalendar(2006, 2, 15), 3287014, 14),
		       new Album("Who's Back?", new GregorianCalendar(2014, 9, 3), 3891204, 14)
		   };
	   
	   private static final Song[] INITIAL_SONG = new Song[]{
			   new Song("Who Do You Love?", 2014, 234, 1657854, 54, "English"),
			   new Song("Left, Right", 2013, 234, 15063156, 44, "English"),
			   new Song("1AM", 2018, 157, 3120598, 97, "English"),
			   new Song("Big Bank", 2018, 237, 133200063, 5, "English"),
			   new Song("Big Bank", 2018, 237, 133200063, 5, "English"),
			   new Song("Big Bank", 2018, 237, 133200063, 5, "English"),
			   new Song("Big Bank", 2018, 237, 133200063, 5, "English"),
			   new Song("Big Bank", 2018, 237, 133200063, 5, "English"),
			   new Song("Big Bank", 2018, 237, 133200063, 5, "English"),
			   new Song("Big Bank", 2018, 237, 133200063, 5, "English"),
			   new Song("Big Bank", 2018, 237, 133200063, 5, "English"),
			   new Song("Big Bank", 2018, 237, 133200063, 5, "English"),
	   };
	   
	   private static final int[] ALBUM_OWNERS = new int[] {
			   1, 1, 1,
			   2, 2, 2,
			   3, 3,
			   4, 4, 4,
			   5, 5,
			   6,
			   7, 7, 7,
			   8, 8, 8,
			   9, 9, 9
	   };
	   
	   private static final int[] SONG_OWNERS = new int[] {
			   1, 1, 1,
			   
	   };
	   
	   private static final int[] SONG_IN_ALBUM = new int[] {
			   1, 1, 1
	   };
   }


